import java.lang.Math;
class Main
{
	public static void main(String[] args)
	{
		int [] partition = new int [201];

		partition[0] = 1;
		partition[1] = 1;
		partition[2] = 1;
		partition[3] = 2;
		partition[4] = 2;
		partition[5] = 3;
		partition[6] = 4;
		partition[7] = 5;
		partition[8] = 6;
		partition[9] = 8;

		int [] pentagonal = {0,1,2,5,7,12,15,22,26,35,40,51,57,70,77,92,100,117,126,145,155,176,187};

		for (int i = 10; i<200; i++)
			{
				int a = 0;
				for (int q = 0; q<i; q++)
					{
						int comb = (int) (3*Math.pow(q,2)) - q;
						if (i==comb)
						{
							a = (int) (Math.pow(-1,q));
							break;
						}
					}
				if (i==14)
					System.out.println(a);
				
				int index = 0;
				for (int w = pentagonal.length-1; w>0; w--)
					{
						if (i>=pentagonal[w])
						{
							index = w;
							break;
						}
					}
				if (i==14)
					System.out.println(index);

				int neg = 1;
				int sum = a;
				for (int j = 1; j<=index; j++)
					{
						boolean negB = ((neg%4==1)||(neg%4==2));
						if (negB)
						{
							sum += partition[i-pentagonal[j]];
							if (i==14)
								System.out.println(sum);
						} else
						{
							sum -= partition[i-pentagonal[j]];
							if (i==14)
								System.out.println(sum);
						}
						neg++;
					}

				partition[i] = sum;
			}

		//System.out.println(partition[14]);
		
		for (int i = 0; i<partition.length; i++)
			{
				System.out.println(i+" "+partition[i]);
			}
		
	}
}